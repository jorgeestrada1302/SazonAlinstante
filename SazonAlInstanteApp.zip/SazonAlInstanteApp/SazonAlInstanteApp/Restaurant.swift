//
//  Restaurant.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//
import Foundation
import CoreLocation

struct Restaurant: Identifiable, Codable {
    let id: UUID
    let name: String
    let coordinate: CLLocationCoordinate2D
    let description: String
    let promotion: String
    let imageName: String
    var rating: Double // Promedio de calificaciones
    var reviews: [Review] // Lista de reseñas
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case description
        case promotion
        case imageName
        case rating
        case reviews
        case latitude
        case longitude
    }
    
    init(name: String, coordinate: CLLocationCoordinate2D, description: String, promotion: String, imageName: String, rating: Double = 0.0, reviews: [Review] = []) {
        self.id = UUID()
        self.name = name
        self.coordinate = coordinate
        self.description = description
        self.promotion = promotion
        self.imageName = imageName
        self.rating = rating
        self.reviews = reviews
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        description = try container.decode(String.self, forKey: .description)
        promotion = try container.decode(String.self, forKey: .promotion)
        imageName = try container.decode(String.self, forKey: .imageName)
        rating = try container.decode(Double.self, forKey: .rating)
        reviews = try container.decode([Review].self, forKey: .reviews)
        let latitude = try container.decode(Double.self, forKey: .latitude)
        let longitude = try container.decode(Double.self, forKey: .longitude)
        coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(name, forKey: .name)
        try container.encode(description, forKey: .description)
        try container.encode(promotion, forKey: .promotion)
        try container.encode(imageName, forKey: .imageName)
        try container.encode(rating, forKey: .rating)
        try container.encode(reviews, forKey: .reviews)
        try container.encode(coordinate.latitude, forKey: .latitude)
        try container.encode(coordinate.longitude, forKey: .longitude)
    }
}

struct Review: Identifiable, Codable {
    let id: UUID
    let userName: String
    let rating: Double
    let comment: String
    let date: Date
    
    init(id: UUID = UUID(), userName: String, rating: Double, comment: String, date: Date) {
        self.id = id
        self.userName = userName
        self.rating = rating
        self.comment = comment
        self.date = date
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        userName = try container.decode(String.self, forKey: .userName)
        rating = try container.decode(Double.self, forKey: .rating)
        comment = try container.decode(String.self, forKey: .comment)
        date = try container.decode(Date.self, forKey: .date)
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case userName
        case rating
        case comment
        case date
    }
}
