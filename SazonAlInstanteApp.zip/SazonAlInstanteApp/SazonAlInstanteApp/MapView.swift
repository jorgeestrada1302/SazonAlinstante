//
//  MapView.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//
import SwiftUI
import MapKit
import CoreLocation

struct Coordinate: Equatable {
    let latitude: Double
    let longitude: Double
    
    static let zero = Coordinate(latitude: 0, longitude: 0)
    
    init(latitude: Double, longitude: Double) {
        self.latitude = latitude
        self.longitude = longitude
    }
    
    init(_ clCoordinate: CLLocationCoordinate2D) {
        self.latitude = clCoordinate.latitude
        self.longitude = clCoordinate.longitude
    }
}

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let locationManager = CLLocationManager()
    @Published var userLocation: Coordinate = .zero
    @Published var locationStatus: CLAuthorizationStatus?
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        checkAuthorizationStatus()
    }
    
    func checkAuthorizationStatus() {
        let status = locationManager.authorizationStatus
        print("Estado de autorización: \(status.rawValue)") // Para depuración
        locationStatus = status
        switch status {
        case .notDetermined:
            print("Solicitando permisos de ubicación...")
            locationManager.requestWhenInUseAuthorization()
        case .authorizedWhenInUse, .authorizedAlways:
            print("Permisos otorgados, iniciando actualización de ubicación...")
            locationManager.startUpdatingLocation()
        default:
            print("Permisos denegados o restringidos.")
            break
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        print("Ubicación actualizada: \(location.coordinate.latitude), \(location.coordinate.longitude)") // Para depuración
        userLocation = Coordinate(location.coordinate)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error al obtener la ubicación: \(error.localizedDescription)")
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        print("Cambio en autorización: \(manager.authorizationStatus.rawValue)") // Para depuración
        locationStatus = manager.authorizationStatus
        checkAuthorizationStatus()
    }
}

// Representación de MKMapView en SwiftUI
struct CustomMapView: UIViewRepresentable {
    @Binding var cameraPosition: MapCameraPosition
    let userLocation: Coordinate
    let restaurants: [Restaurant]
    @Binding var selectedRestaurant: Restaurant?
    @Binding var showDetail: Bool
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = true
        mapView.isUserInteractionEnabled = true
        return mapView
    }
    
    func updateUIView(_ uiView: MKMapView, context: Context) {
        if let region = cameraPosition.region {
            uiView.setRegion(region, animated: true)
        }
        
        uiView.removeAnnotations(uiView.annotations)
        
        for restaurant in restaurants {
            let annotation = MKPointAnnotation()
            annotation.title = restaurant.name
            annotation.coordinate = restaurant.coordinate
            uiView.addAnnotation(annotation)
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: CustomMapView
        
        init(_ parent: CustomMapView) {
            self.parent = parent
        }
        
        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
            guard let title = view.annotation?.title, let restaurantName = title else { return }
            if let restaurant = parent.restaurants.first(where: { $0.name == restaurantName }) {
                parent.selectedRestaurant = restaurant
                parent.showDetail = true
            }
        }
    }
}

struct MapView: View {
    @StateObject private var locationManager = LocationManager()
    @Environment(\.dismiss) var dismiss
    @ObservedObject var appState: AppState
    
    @State private var cameraPosition: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 19.4326, longitude: -99.1332),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
    )
    
    @State private var restaurants: [Restaurant] = [
        Restaurant(
            name: "Taquería El Sabor",
            coordinate: CLLocationCoordinate2D(latitude: 19.4326, longitude: -99.1332),
            description: "Auténticos tacos mexicanos con salsas caseras.",
            promotion: "2x1 en tacos al pastor",
            imageName: "tacos",
            rating: 4.5,
            reviews: [
                Review(userName: "Juan Pérez", rating: 4.5, comment: "¡Los tacos al pastor son increíbles!", date: Date())
            ]
        ),
        Restaurant(
            name: "Pizzería Italiana",
            coordinate: CLLocationCoordinate2D(latitude: 19.4350, longitude: -99.1300),
            description: "Pizzas artesanales al horno de leña.",
            promotion: "Pizza gratis con compra mínima",
            imageName: "pizza",
            rating: 4.8,
            reviews: [
                Review(userName: "María Gómez", rating: 4.8, comment: "La mejor pizza que he probado.", date: Date())
            ]
        ),
        Restaurant(
            name: "Sushi Zen",
            coordinate: CLLocationCoordinate2D(latitude: 19.4300, longitude: -99.1360),
            description: "Sushi fresco con ingredientes de calidad.",
            promotion: "30% off en rolls seleccionados",
            imageName: "sushi",
            rating: 4.2,
            reviews: [
                Review(userName: "Carlos López", rating: 4.2, comment: "Sushi fresco y delicioso.", date: Date())
            ]
        )
    ]
    
    @State private var selectedRestaurant: Restaurant?
    @State private var showDetail = false
    @State private var showReviewForm = false
    @State private var reviewRating: Double = 3.0
    @State private var reviewComment: String = ""
    
    // Calcular la distancia al restaurante seleccionado
    func distanceToRestaurant(_ restaurant: Restaurant) -> String {
        guard locationManager.userLocation != .zero else { return "Ubicación no disponible" }
        let userLocation = CLLocation(latitude: locationManager.userLocation.latitude, longitude: locationManager.userLocation.longitude)
        let restaurantLocation = CLLocation(latitude: restaurant.coordinate.latitude, longitude: restaurant.coordinate.longitude)
        let distance = restaurantLocation.distance(from: userLocation)
        return String(format: "%.2f km", distance / 1000)
    }
    
    // Añadir una reseña
    func addReview(to restaurant: Restaurant) {
        guard let index = restaurants.firstIndex(where: { $0.id == restaurant.id }) else { return }
        var updatedRestaurant = restaurants[index]
        let newReview = Review(userName: "Usuario", rating: reviewRating, comment: reviewComment, date: Date())
        updatedRestaurant.reviews.append(newReview)
        updatedRestaurant.rating = updatedRestaurant.reviews.reduce(0.0) { $0 + $1.rating } / Double(updatedRestaurant.reviews.count)
        restaurants[index] = updatedRestaurant
        saveRestaurants()
    }
    
    // Guardar restaurantes (simulando almacenamiento local)
    private func saveRestaurants() {
        if let encoded = try? JSONEncoder().encode(restaurants) {
            UserDefaults.standard.set(encoded, forKey: "restaurants")
        }
    }
    
    // Cargar restaurantes (simulando almacenamiento local)
    private func loadRestaurants() {
        if let data = UserDefaults.standard.data(forKey: "restaurants"),
           let savedRestaurants = try? JSONDecoder().decode([Restaurant].self, from: data) {
            restaurants = savedRestaurants
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                // Mapa usando MKMapView
                CustomMapView(
                    cameraPosition: $cameraPosition,
                    userLocation: locationManager.userLocation,
                    restaurants: restaurants,
                    selectedRestaurant: $selectedRestaurant,
                    showDetail: $showDetail
                )
                .ignoresSafeArea()
                
                // Fondo con gradiente
                LinearGradient(gradient: Gradient(colors: [Color.orange.opacity(0.3), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                
                // Mensaje si los permisos de ubicación no están otorgados
                if locationManager.locationStatus == .denied || locationManager.locationStatus == .restricted {
                    VStack {
                        Spacer()
                        VStack {
                            Text("Por favor, habilita los permisos de ubicación en los ajustes para ver restaurantes cercanos.")
                                .multilineTextAlignment(.center)
                                .foregroundColor(.white)
                                .padding()
                            Button(action: {
                                if let url = URL(string: UIApplication.openSettingsURLString) {
                                    UIApplication.shared.open(url)
                                }
                            }) {
                                Text("Abrir Ajustes")
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.orange)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .font(.system(size: 16, weight: .bold))
                            }
                        }
                        .padding()
                        .background(Color.red.opacity(0.9))
                        .cornerRadius(15)
                        .padding()
                        Spacer()
                    }
                }
                
                // Detalle del restaurante seleccionado
                if showDetail, let selectedRestaurant = selectedRestaurant {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text(selectedRestaurant.name)
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(.orange)
                            Spacer()
                            Button(action: {
                                withAnimation(.spring()) {
                                    showDetail = false
                                    self.selectedRestaurant = nil
                                }
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                        Image(selectedRestaurant.imageName)
                            .resizable()
                            .scaledToFill()
                            .frame(height: 150)
                            .cornerRadius(15)
                            .clipped()
                            .shadow(radius: 3)
                        Text(selectedRestaurant.description)
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                        Text("Promoción: \(selectedRestaurant.promotion)")
                            .font(.system(size: 14))
                            .foregroundColor(.green)
                        Text("Distancia: \(distanceToRestaurant(selectedRestaurant))")
                            .font(.system(size: 14))
                            .foregroundColor(.blue)
                        HStack {
                            Text("Calificación: \(String(format: "%.1f", selectedRestaurant.rating))")
                                .font(.system(size: 14))
                                .foregroundColor(.yellow)
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                        }
                        Button(action: {
                            withAnimation(.spring()) {
                                showDetail = false
                                appState.selectedRestaurantForReservation = selectedRestaurant.name
                                appState.selectedTab = 2 // Navegar a la pestaña de Reservas
                            }
                        }) {
                            Text("Hacer Reserva")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.orange)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .font(.system(size: 16, weight: .bold))
                        }
                        Button(action: {
                            showReviewForm = true
                        }) {
                            Text("Dejar Reseña")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .font(.system(size: 16, weight: .bold))
                        }
                        // Mostrar reseñas
                        ScrollView {
                            VStack(alignment: .leading, spacing: 10) {
                                ForEach(selectedRestaurant.reviews) { review in
                                    VStack(alignment: .leading, spacing: 5) {
                                        HStack {
                                            Text(review.userName)
                                                .font(.system(size: 14, weight: .bold))
                                                .foregroundColor(.black)
                                            Spacer()
                                            Text("\(String(format: "%.1f", review.rating))")
                                                .font(.system(size: 14))
                                                .foregroundColor(.yellow)
                                            Image(systemName: "star.fill")
                                                .foregroundColor(.yellow)
                                        }
                                        Text(review.comment)
                                            .font(.system(size: 14))
                                            .foregroundColor(.gray)
                                        Text(review.date, style: .date)
                                            .font(.system(size: 12))
                                            .foregroundColor(.gray)
                                    }
                                    .padding(.vertical, 5)
                                    .padding(.horizontal, 10)
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(10)
                                }
                            }
                        }
                        .frame(maxHeight: 150)
                    }
                    .padding()
                    .background(Color.white.opacity(0.95))
                    .cornerRadius(15)
                    .shadow(radius: 5)
                    .padding()
                    .scaleEffect(showDetail ? 1.0 : 0.8)
                    .animation(.spring(), value: showDetail)
                    .sheet(isPresented: $showReviewForm) {
                        // Formulario para dejar reseña
                        VStack(spacing: 20) {
                            Text("Dejar Reseña para \(selectedRestaurant.name)")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.orange)
                            
                            Slider(value: $reviewRating, in: 1...5, step: 0.5) {
                                Text("Calificación")
                            }
                            .padding(.horizontal)
                            Text("Calificación: \(String(format: "%.1f", reviewRating))")
                                .font(.system(size: 16))
                                .foregroundColor(.gray)
                            
                            TextField("Comentario", text: $reviewComment)
                                .padding()
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                                .font(.system(size: 16))
                            
                            Button(action: {
                                addReview(to: selectedRestaurant)
                                reviewRating = 3.0
                                reviewComment = ""
                                showReviewForm = false
                            }) {
                                Text("Enviar Reseña")
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .font(.system(size: 16, weight: .bold))
                            }
                            .disabled(reviewComment.isEmpty)
                            .padding(.horizontal)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(radius: 5)
                    }
                }
            }
            .navigationTitle("Restaurantes Cercanos")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        if let restaurant = selectedRestaurant {
                            let url = URL(string: "https://maps.google.com/?q=\(restaurant.coordinate.latitude),\(restaurant.coordinate.longitude)")!
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Image(systemName: "map.fill")
                            .foregroundColor(selectedRestaurant == nil ? .gray : .orange)
                    }
                    .disabled(selectedRestaurant == nil)
                }
            }
            .onChange(of: locationManager.userLocation) { oldValue, newValue in
                if newValue != .zero {
                    cameraPosition = .region(
                        MKCoordinateRegion(
                            center: CLLocationCoordinate2D(latitude: newValue.latitude, longitude: newValue.longitude),
                            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                        )
                    )
                }
            }
            .onAppear {
                loadRestaurants()
            }
        }
    }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView(appState: AppState())
    }
}
