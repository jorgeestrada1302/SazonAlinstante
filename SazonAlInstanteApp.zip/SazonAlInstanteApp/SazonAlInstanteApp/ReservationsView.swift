//
//  ReservationsView.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//
import SwiftUI

struct ReservationsView: View {
    @ObservedObject var appState: AppState
    @State private var name = ""
    @State private var date = Date()
    @State private var people = 1
    @State private var selectedRestaurant: String = "Tacos Don Luis"
    
    let restaurants = [
        "Tacos Don Luis",
        "La Terraza",
        "LINZ"
    ]
    
    @State private var reservations: [Reservation] = []
    
    // Vista auxiliar para el fondo con gradiente
    private var backgroundGradient: some View {
        LinearGradient(gradient: Gradient(colors: [Color.orange.opacity(0.3), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
    }
    
    // Vista auxiliar para el campo de texto
    private var nameField: some View {
        TextField("Nombre", text: $name)
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
            .font(.system(size: 16))
    }
    
    // Vista auxiliar para el selector de fecha
    private var datePicker: some View {
        DatePicker("Fecha y hora", selection: $date, displayedComponents: [.date, .hourAndMinute])
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
            .font(.system(size: 16))
    }
    
    // Vista auxiliar para el stepper de personas
    private var peopleStepper: some View {
        Stepper("Personas: \(people)", value: $people, in: 1...20)
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
            .font(.system(size: 16))
    }
    
    // Vista auxiliar para el picker de restaurantes
    private var restaurantPicker: some View {
        Picker("Restaurante", selection: $selectedRestaurant) {
            ForEach(restaurants, id: \.self) { restaurant in
                Text(restaurant)
            }
        }
        .pickerStyle(.menu)
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(10)
        .font(.system(size: 16))
    }
    
    // Vista auxiliar para el botón de reservar
    private var reserveButton: some View {
        Button(action: {
            let newReservation = Reservation(
                id: UUID(),
                name: name,
                date: date,
                people: people,
                restaurantName: selectedRestaurant,
                status: "Pendiente"
            )
            withAnimation(.spring()) {
                reservations.append(newReservation)
                saveReservations()
                
                name = ""
                date = Date()
                people = 1
                selectedRestaurant = restaurants[0]
            }
        }) {
            Text("Reservar")
                .frame(maxWidth: .infinity)
                .padding()
                .background(name.isEmpty ? Color.gray : Color.orange)
                .foregroundColor(.white)
                .cornerRadius(10)
                .font(.system(size: 16, weight: .bold))
        }
        .disabled(name.isEmpty)
    }
    
    // Vista auxiliar para el formulario de nueva reserva
    private var newReservationForm: some View {
        VStack {
            Text("Nueva Reserva")
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.orange)
                .padding(.bottom, 10)
            
            nameField
            datePicker
            peopleStepper
            restaurantPicker
            reserveButton
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .padding(.horizontal)
    }
    
    // Vista auxiliar para una tarjeta de reserva
    private func reservationCard(_ reservation: Reservation) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text("Restaurante: \(reservation.restaurantName)")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.orange)
                Spacer()
                Text(reservation.status)
                    .font(.system(size: 14))
                    .foregroundColor(reservation.status == "Pendiente" ? .green : .red)
            }
            Text("Nombre: \(reservation.name)")
                .font(.system(size: 14))
                .foregroundColor(.black)
            Text("Fecha: \(reservation.date, style: .date) \(reservation.date, style: .time)")
                .font(.system(size: 14))
                .foregroundColor(.gray)
            Text("Personas: \(reservation.people)")
                .font(.system(size: 14))
                .foregroundColor(.gray)
            if reservation.status == "Pendiente" {
                Button(action: {
                    withAnimation(.spring()) {
                        if let index = reservations.firstIndex(where: { $0.id == reservation.id }) {
                            var updatedReservation = reservations[index]
                            updatedReservation.status = "Cancelada"
                            reservations[index] = updatedReservation
                            saveReservations()
                        }
                    }
                }) {
                    Text("Cancelar Reserva")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .font(.system(size: 14, weight: .bold))
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .padding(.horizontal)
        .scaleEffect(1.0)
    }
    
    // Vista auxiliar para la sección de reservas guardadas
    private var savedReservationsSection: some View {
        VStack {
            Text("Reservas Guardadas")
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.orange)
                .padding(.bottom, 10)
            
            if reservations.isEmpty {
                Text("No hay reservas aún.")
                    .foregroundColor(.gray)
                    .font(.system(size: 16))
                    .padding()
            } else {
                ForEach(reservations) { reservation in
                    reservationCard(reservation)
                }
            }
        }
        .padding(.vertical)
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                
                ScrollView {
                    VStack(spacing: 20) {
                        newReservationForm
                        savedReservationsSection
                    }
                    .padding(.vertical)
                }
            }
            .navigationTitle("Reservas")
        }
        .onAppear {
            loadReservations()
            if let restaurant = appState.selectedRestaurantForReservation {
                selectedRestaurant = restaurant
                appState.selectedRestaurantForReservation = nil
            }
        }
    }
    
    private func saveReservations() {
        if let encoded = try? JSONEncoder().encode(reservations) {
            UserDefaults.standard.set(encoded, forKey: "reservations")
        }
    }
    
    private func loadReservations() {
        if let data = UserDefaults.standard.data(forKey: "reservations"),
           let savedReservations = try? JSONDecoder().decode([Reservation].self, from: data) {
            reservations = savedReservations
        }
    }
}

struct ReservationsView_Previews: PreviewProvider {
    static var previews: some View {
        ReservationsView(appState: AppState())
    }
}
