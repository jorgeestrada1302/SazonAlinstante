//
//  SazonAlInstanteAppApp.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//

import SwiftUI

@main
struct SazonAlInstanteApp: App {
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            if appState.hasSeenOnboarding {
                ContentView()
                    .environmentObject(appState)
            } else {
                OnboardingView(hasSeenOnboarding: $appState.hasSeenOnboarding)
                    .environmentObject(appState)
            }
        }
    }
}
