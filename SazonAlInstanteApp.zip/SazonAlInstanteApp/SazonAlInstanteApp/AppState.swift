//
//  AppState.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//
import SwiftUI

class AppState: ObservableObject {
    @Published var selectedTab: Int = 0 // 0: Promociones, 1: Mapa, 2: Reservas
    @Published var selectedRestaurantForReservation: String? // Restaurante preseleccionado para reserva
    @Published var hasSeenOnboarding: Bool = UserDefaults.standard.bool(forKey: "hasSeenOnboarding") // Para controlar si se ha visto el onboarding
}
