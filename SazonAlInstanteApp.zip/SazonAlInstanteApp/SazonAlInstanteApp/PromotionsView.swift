//
//  PromotionsView.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//
import SwiftUI

struct PromotionsView: View {
    let promotions = [
        Promotion(title: "Tacos Don Luis", restaurant: "Tacos Don Luis", category: "Mexicana", discount: "50%", timeLeft: "1 hora", imageName: "tacos", restrictions: "Válido de 12-2 PM"),
        Promotion(title: "La Terraza", restaurant: "La Terraza", category: "Italiana", discount: "100%", timeLeft: "30 min", imageName: "pizza", restrictions: "Compra mínima $200"),
        Promotion(title: "Linz Panorama", restaurant: "Linz Panorama", category: "Japonesa", discount: "30%", timeLeft: "2 horas", imageName: "sushi", restrictions: "Solo en sitio")
    ]
    
    @State private var selectedCategory = "Todas"
    let categories = ["Todas", "Mexicana", "Italiana", "Japonesa", "Rápida"]
    
    var filteredPromotions: [Promotion] {
        if selectedCategory == "Todas" {
            return promotions
        } else {
            return promotions.filter { $0.category == selectedCategory }
        }
    }
    
    // Vista auxiliar para el fondo con gradiente
    private var backgroundGradient: some View {
        LinearGradient(gradient: Gradient(colors: [Color.orange.opacity(0.3), Color.yellow.opacity(0.3)]), startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
    }
    
    // Vista auxiliar para el picker de categorías
    private var categoryPicker: some View {
        Picker("Categoría", selection: $selectedCategory) {
            ForEach(categories, id: \.self) { category in
                Text(category)
            }
        }
        .pickerStyle(.segmented)
        .padding()
        .background(Color.white.opacity(0.9))
        .cornerRadius(10)
        .padding(.horizontal)
        .shadow(radius: 2)
        .onChange(of: selectedCategory) { oldValue, newValue in
            withAnimation(.spring()) {
                selectedCategory = newValue
            }
        }
    }
    
    // Vista auxiliar para una tarjeta de promoción
    private func promotionCard(_ promotion: Promotion) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(promotion.imageName)
                .resizable()
                .scaledToFill()
                .frame(height: 150)
                .cornerRadius(15)
                .clipped()
                .shadow(radius: 3)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(promotion.title)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.black)
                Text(promotion.restaurant)
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                Text("Descuento: \(promotion.discount)")
                    .font(.system(size: 16))
                    .foregroundColor(.green)
                Text("Tiempo restante: \(promotion.timeLeft)")
                    .font(.system(size: 16))
                    .foregroundColor(.red)
                Text("Restricciones: \(promotion.restrictions)")
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
            }
            .padding(.horizontal)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .padding(.horizontal)
        .scaleEffect(1.0)
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                
                VStack {
                    categoryPicker
                    
                    ScrollView {
                        VStack(spacing: 15) {
                            ForEach(filteredPromotions) { promotion in
                                promotionCard(promotion)
                            }
                        }
                        .padding(.vertical)
                    }
                }
            }
            .navigationTitle("Promociones")
        }
    }
}

struct PromotionsView_Previews: PreviewProvider {
    static var previews: some View {
        PromotionsView()
    }
}
