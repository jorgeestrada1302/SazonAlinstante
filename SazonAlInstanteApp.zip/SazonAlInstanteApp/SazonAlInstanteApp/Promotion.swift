//
//  Promotion.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//
import Foundation

struct Promotion: Identifiable {
    let id = UUID()
    let title: String
    let restaurant: String
    let category: String
    let discount: String
    let timeLeft: String
    let imageName: String
    let restrictions: String
}
