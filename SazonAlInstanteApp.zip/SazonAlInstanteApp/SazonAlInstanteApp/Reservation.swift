//
//  Reservation.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//
import Foundation

struct Reservation: Identifiable, Codable {
    let id: UUID
    var name: String
    var date: Date
    var people: Int
    var restaurantName: String
    var status: String // "Pendiente", "Confirmada", "Cancelada"
    
    init(id: UUID = UUID(), name: String, date: Date, people: Int, restaurantName: String, status: String = "Pendiente") {
        self.id = id
        self.name = name
        self.date = date
        self.people = people
        self.restaurantName = restaurantName
        self.status = status
    }
}
