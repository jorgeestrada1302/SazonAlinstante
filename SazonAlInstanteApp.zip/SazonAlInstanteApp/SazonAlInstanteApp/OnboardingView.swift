//
//  OnboardingView.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//
import SwiftUI

struct OnboardingView: View {
    @Binding var hasSeenOnboarding: Bool
    @StateObject private var locationManager = LocationManager()
    
    var body: some View {
        TabView {
            // Pantalla 1: Bienvenida
            VStack(spacing: 20) {
                Image(systemName: "fork.knife.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.orange)
                
                Text("¡Bienvenido a Sazón al Instante!")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.orange)
                
                Text("Descubre los mejores restaurantes, promociones y haz reservas fácilmente.")
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Spacer()
            }
            .padding(.top, 50)
            
            // Pantalla 2: Promociones
            VStack(spacing: 20) {
                Image(systemName: "tag.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.orange)
                
                Text("Explora Promociones")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.orange)
                
                Text("Encuentra las mejores ofertas en tus restaurantes favoritos.")
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Spacer()
            }
            .padding(.top, 50)
            
            // Pantalla 3: Mapa
            VStack(spacing: 20) {
                Image(systemName: "map.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.orange)
                
                Text("Encuentra Restaurantes")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.orange)
                
                Text("Descubre restaurantes cercanos y haz reservas al instante.")
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Spacer()
            }
            .padding(.top, 50)
            
            // Pantalla 4: Permisos de ubicación
            VStack(spacing: 20) {
                Image(systemName: "location.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.orange)
                
                Text("Habilita tu Ubicación")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.orange)
                
                Text("Necesitamos tu ubicación para mostrarte restaurantes cercanos. ¿Nos das permiso?")
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Button(action: {
                    locationManager.checkAuthorizationStatus()
                }) {
                    Text("Permitir Ubicación")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .font(.system(size: 16, weight: .bold))
                }
                .padding(.horizontal)
                
                Button(action: {
                    withAnimation(.spring()) {
                        hasSeenOnboarding = true
                        UserDefaults.standard.set(true, forKey: "hasSeenOnboarding")
                    }
                }) {
                    Text("Continuar sin ubicación")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.gray.opacity(0.3))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .font(.system(size: 16, weight: .bold))
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .padding(.top, 50)
        }
        .tabViewStyle(PageTabViewStyle())
        .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
        .background(
            LinearGradient(gradient: Gradient(colors: [Color.orange.opacity(0.1), Color.yellow.opacity(0.1)]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
        )
    }
}

struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingView(hasSeenOnboarding: .constant(false))
    }
}
