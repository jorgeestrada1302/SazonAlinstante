//
//  ContentView.swift
//  SazonAlInstanteApp
//
//  Created by Jorge Cano on 21/03/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var appState = AppState()
    
    var body: some View {
        TabView(selection: $appState.selectedTab) {
            PromotionsView()
                .tabItem {
                    Label("Promociones", systemImage: "tag.fill")
                }
                .tag(0)
            
            MapView(appState: appState)
                .tabItem {
                    Label("Mapa", systemImage: "map.fill")
                }
                .tag(1)
            
            ReservationsView(appState: appState)
                .tabItem {
                    Label("Reservas", systemImage: "calendar")
                }
                .tag(2)
        }
        .accentColor(.orange)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
